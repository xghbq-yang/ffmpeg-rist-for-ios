## 5.1.0
- Feature release based on native v5.1
- Implements AbstractSession.cancel() method
- Runs iOS and macOS callbacks on main queue

## 5.1.0-LTS
- Feature release based on native v5.1.LTS
- Implements AbstractSession.cancel() method
- Runs iOS and macOS callbacks on main queue

## 4.5.1
- Feature release based on native v4.5.1

## 4.5.1-LTS
- Feature release based on native v4.5.1.LTS

## 4.5.0
- Initial release

## 4.5.0-LTS
- Initial LTS release