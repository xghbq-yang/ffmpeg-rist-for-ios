## 0.2.1
- Fixes the signature of getMediaInformation method 

## 0.2.0
- Implements execute methods
- Merges existing getSafParameter methods into a single method with a new openMode parameter
- Adds list media information sessions methods to FFprobeKit
- Adds getMediaInformation method

## 0.1.0
- Initial release
