# Platform Interface for FFmpegKit Flutter

A common platform interface for the [`ffmpeg_kit_flutter`][1] plugin.

This interface allows platform-specific implementations of the `ffmpeg_kit_flutter`
plugin, as well as the plugin itself, to ensure they are supporting the same
interface.

[1]: ../flutter
