#!/bin/bash

BUILD_DIR="${BASEDIR}/src/librist/build"

rm -rf "${BUILD_DIR}" || return 1

mkdir -p "${BUILD_DIR}" || return 1
cd "${BUILD_DIR}" || return 1

meson .. --default-library=static --buildtype=release -Db_lto=true || return 1

sudo ninja install || return 1

#cd "${BUILD_DIR}" && \
#meson .. --default-library=static --buildtype=release -Db_lto=true && \
#sudo ninja install
    
# MANUALLY COPY PKG-CONFIG FILES
cp ./*.pc "${INSTALL_PKG_CONFIG_DIR}" || return 1
