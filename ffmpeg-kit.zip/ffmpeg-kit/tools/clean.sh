#!/bin/bash

rm -rf ../prebuilt
rm -rf ../.tmp
rm -f ../build.log

rm -rf ../android/build
rm -rf ../android/ffmpeg-kit-android-lib/build
rm -rf ../android/obj
rm -rf ../android/libs

rm -rf ../src/*

rm -rf ../apple/src/.deps
rm -rf ../apple/src/.libs

rm -rf ../linux/src/.deps
rm -rf ../linux/src/.libs
